""" Логика проекта. """
from .filter import DocumentFilterMixin


class DocumentMixin(DocumentFilterMixin):
    """ Настройка проекта. """
