$(document).ready(function() {
    bps_template_project.init();
});

var correspondence = {

    init: function() {

    }

}
